from django.apps import AppConfig


class UpvotingConfig(AppConfig):
    name = 'upvoting'
