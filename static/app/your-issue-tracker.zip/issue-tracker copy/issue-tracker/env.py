import os

os.environ.setdefault('STRIPE_PUBLISHABLE', 'pk_test_esj4tSEDVsMRL2EHnUoIeoBj00VqLbUc4k')
os.environ.setdefault('STRIPE_SECRET', 'sk_test_17p0CRA7ovRSV7l2Prq5LqzE00UwC1IDZB')
os.environ.setdefault('SECRET_KEY', 'om!93v%yk^x^i&197_cyl7@dbi1aipej)_2$0a&2jf4pa5ywn6')
os.environ.setdefault('EMAIL_ADDRESS', '3cdf2a13a41f3e')
os.environ.setdefault('PASSWORD', '048606417c8592')
os.environ.setdefault('EMAIL_HOST', 'smtp.mailtrap.io')
os.environ.setdefault('EMAIL_PORT', '2525')

